 <section>
            <div class="mainwrapper">
                <div class="leftpanel">
                    <div class="media profile-left">
                        <a class="pull-left profile-thumb" href="profile.php">
                            <img class="img-circle" src="images/photos/profile.png" alt="">
                        </a>
                        <div class="media-body">
                            <h4 class="media-heading">Peter Okoye</h4>
                            <small class="text-muted">MERCHANT</small>
                        </div>
                    </div><!-- media -->
                    
                    <ul class="nav nav-pills nav-stacked">
                        <li class="active"><a href="index.php"><i class="fa fa-home"></i> <span>Dashboard</span></a></li>
                        <li><a href="integration.php"><i class="fa fa-cog"></i> <span>Website Integration</span></a></li>
                        <li><a href="bankaccounts.php"><i class="fa fa-bank"></i> <span>Bank Accounts</span></a></li>
                        <li><a href="transactions.php"><span class="pull-right badge">2</span> <i class="fa fa-bell"></i> <span>Transactions</span></a></li>
                        <li><a href="notification.php"><span class="pull-right badge">1</span><i class="fa fa-envelope-o"></i> <span>Notifications</span></a></li>
                        <li><a href="#"><span class="pull-right"><i class="fa fa-lock"></i></span><i class="fa fa-bar-chart-o"></i> <span>Earning Analytics</span></a></li>
                       
                        
                    </ul>
                    
                </div><!-- leftpanel -->